/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tnp.dao;

import com.tnp.bean.UsersBean;
import com.tnp.utility.ConnectionPool;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author yasht
 */
public class UsersDAO {
    static Connection conn;
    public int registerUser(UsersBean ub){
    conn = ConnectionPool.connectDB();
    int r=0;
    String sql= "insert into users(name,email,address,username,password)values('"+ub.getName()+"','"+ub.getEmail()+"','"+ub.getAddress()+"','"+ub.getUserName()+"','"+ub.getPassword()+"')";
        try {
            Statement stmt=conn.createStatement();
            r=stmt.executeUpdate(sql);
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(UsersDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
    
    
    return r;
    
    
        
    }
    //2. Login check method
    
    public int loginCheck(String username,String password){
    
        int id=0;
        conn=ConnectionPool.connectDB();
        String sql="select uid from users where username='"+username+"'and password='"+password+"'";
        Statement stmt;
        try {
            stmt = conn.createStatement();
             ResultSet rs=stmt.executeQuery(sql);
        if(rs.next()){
        
            id = rs.getInt("uid");
        }
        conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(UsersDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        
        return id;
    }
    // 3. method to show password
    public String forgotPassword(String email){
    
        String pwd=null;
        conn=ConnectionPool.connectDB();
        String sql = "select password from users where email='"+email+"'";
        try {
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            if(rs.next()){
            
                pwd=rs.getString("password");
            }
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(UsersDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return pwd;
    }
    public int changePassword(String email,String oldPassword,String newPassword){
    
        conn=ConnectionPool.connectDB();
        String select1="select uid from users where password='"+oldPassword+"'";
        int id=0;
        try {
            Statement stmt=conn.createStatement();
            ResultSet rs1=stmt.executeQuery(select1);
            if(rs1.next()){
            
               String sql="update users set password='"+newPassword+"'where email='"+email+"'";
               Statement stmt1=conn.createStatement();
               id = stmt1.executeUpdate(sql);
            }
            conn.close();
            
        } catch (SQLException ex) {
            Logger.getLogger(UsersDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return id;
    }
     
    
    
    public static void main(String[] args) throws SQLException {
//        UsersBean ub=new UsersBean();
//        ub.setAddress("Bhopal");
//        ub.setEmail("yashtweb.tech@gmail.com");
//        ub.setMobile("8103356759");
//        ub.setName("Yash Tiwari");
//        ub.setPassword("12345");
//        ub.setUserName("yashuuu.14");
        
//        UsersDAO ud=new UsersDAO();
//        int x=ud.registerUser(ub);
//        if(x>0){
//        
//            System.out.println("Registration Success!!"); 
//        }
//        else{
//        
//            System.out.println("Registration Failed!!");
//        }
        
//2. call login check method 
//UsersDAO ud = new UsersDAO();
//int a = ud.loginCheck("yashuuu.14", "12345");
//if(a>0){
//
//    System.out.println("Login Success!!");
//}
//else{
//
//    System.out.println("Logn Failed, Please Try Again :)");
//}
//3. call forgot password method 
//UsersDAO ud=new UsersDAO();
//String ps =ud.forgotPassword("yashtweb.tech@gmail.com");
//        System.out.println("Your Password: "+ps); 

//4. call change password method
UsersDAO ud=new UsersDAO();
int x=ud.changePassword("yashtweb.tech@gmail.com", "12345", "ABCDE");
        System.out.println(""+x);




    }
    
}
