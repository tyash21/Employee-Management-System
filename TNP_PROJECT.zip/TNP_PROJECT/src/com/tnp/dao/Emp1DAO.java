/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tnp.dao;

import com.tnp.bean.Emp1Bean;
import com.tnp.utility.ConnectionPool;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author yasht
 */
public class Emp1DAO{
    static Connection conn;
    
    //1. for add new employee
    public int saveEmployee(Emp1Bean eb){
        conn=ConnectionPool.connectDB();
        int r=0;
        String sql="insert into emp1(name,sal,deptno,gender,comm) values('"+eb.getName()+"','"+eb.getSal()+"','"+eb.getDeptno()+"','"+eb.getGender()+"','"+eb.getComm()+"')";
        try {
            Statement stmt=conn.createStatement();
            r=stmt.executeUpdate(sql);
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(Emp1DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return r;    
    }
    
    //2. for update employee
    
    public int updateEmployee(Emp1Bean eb){
    
       conn=ConnectionPool.connectDB();
        int r=0;
        String sql="update emp1 set name='"+eb.getName()+"',sal='"+eb.getSal()+"',deptno='"+eb.getDeptno()+"',gender='"+eb.getGender()+"',comm='"+eb.getComm()+"'where empno='"+eb.getEmpnno()+"'";
        try {
            Statement stmt=conn.createStatement();
            r=stmt.executeUpdate(sql);
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(Emp1DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return r;
    }
    
    //3. for delete the employee
    public int deleteEmployee(int empno){
        int r=0;
        conn=ConnectionPool.connectDB();
        String sql="delete from emp1 where empno='"+empno+"'";
        try {
            Statement stmt=conn.createStatement();
            r=stmt.executeUpdate(sql);
            conn.close();
            
        } catch (SQLException ex) {
            Logger.getLogger(Emp1DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return r;
        
    
       }
    //4. find all employee
    
     public ArrayList<Emp1Bean>findAll(){
        conn=ConnectionPool.connectDB();
        ArrayList<Emp1Bean>al=new ArrayList<Emp1Bean>();
        String sql="select*from emp1";
        try {
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            while(rs.next()){
              Emp1Bean e=new Emp1Bean();
              e.setEmpnno(rs.getInt("empno"));
              e.setComm(rs.getFloat("comm"));
              e.setDeptno(rs.getInt("deptno"));
              e.setGender(rs.getString("gender"));
              e.setSal(rs.getFloat("sal"));
              e.setName(rs.getString("name"));
              al.add(e);
              
            }
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(Emp1DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return al;
     }
    //5. Find by gender
     
      public ArrayList<Emp1Bean>findByGender(String gender){
        conn=ConnectionPool.connectDB();
        ArrayList<Emp1Bean>al=new ArrayList<Emp1Bean>();
        String sql="select*from emp1 where gender='"+gender+"'";
        try {
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            while(rs.next()){
              Emp1Bean e=new Emp1Bean();
              e.setEmpnno(rs.getInt("empno"));
              e.setComm(rs.getFloat("comm"));
              e.setDeptno(rs.getInt("deptno"));
              e.setGender(rs.getString("gender"));
              e.setSal(rs.getFloat("sal"));
              e.setName(rs.getString("name"));
              al.add(e);
              
            }
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(Emp1DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return al;
     }
      
    //6. find total salary
      
      public float getTotalSalary(){
      conn=ConnectionPool.connectDB();
      float s=0;
      String sql="select sum(sal) as tsal from emp1";
        try {
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            if(rs.next()){
            s=rs.getFloat("tsal");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Emp1DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return s;
      }
      
         //7. find average salary
      
      public float getAverageSalary(){
      conn=ConnectionPool.connectDB();
      float s=0;
      String sql="select avg(sal) as tsal from emp1";
        try {
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            if(rs.next()){
            s=rs.getFloat("tsal");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Emp1DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return s;
      }
//     8. findallBydeptno
      
        public ArrayList<Emp1Bean>findAllByDeptno(int deptno){
        conn=ConnectionPool.connectDB();
        ArrayList<Emp1Bean>al=new ArrayList<Emp1Bean>();
        String sql="select*from emp1 where deptno='"+deptno+"'";
        try {
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            while(rs.next()){
              Emp1Bean e=new Emp1Bean();
              e.setEmpnno(rs.getInt("empno"));
              e.setComm(rs.getFloat("comm"));
              e.setDeptno(rs.getInt("deptno"));
              e.setGender(rs.getString("gender"));
              e.setSal(rs.getFloat("sal"));
              e.setName(rs.getString("name"));
              al.add(e);
              
            }
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(Emp1DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return al;
     }
      
      
     //9.getHighestSalariedEmployee
      
         public ArrayList<Emp1Bean>getHighestSalariedEmployee(){
        conn=ConnectionPool.connectDB();
        ArrayList<Emp1Bean>al=new ArrayList<Emp1Bean>();
        String sql="select*from emp1 where sal=(select max(sal) from emp1)";
        try {
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            while(rs.next()){
              Emp1Bean e=new Emp1Bean();
              e.setEmpnno(rs.getInt("empno"));
              e.setComm(rs.getFloat("comm"));
              e.setDeptno(rs.getInt("deptno"));
              e.setGender(rs.getString("gender"));
              e.setSal(rs.getFloat("sal"));
              e.setName(rs.getString("name"));
              al.add(e);
              
            }
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(Emp1DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return al;
     }
      
       
     //10.getLowestSalariedEmployee
      
         public ArrayList<Emp1Bean>getLowestSalariedEmployee(){
        conn=ConnectionPool.connectDB();
        ArrayList<Emp1Bean>al=new ArrayList<Emp1Bean>();
        String sql="select*from emp1 where sal=(select min(sal) from emp1)";
        try {
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery(sql);
            while(rs.next()){
              Emp1Bean e=new Emp1Bean();
              e.setEmpnno(rs.getInt("empno"));
              e.setComm(rs.getFloat("comm"));
              e.setDeptno(rs.getInt("deptno"));
              e.setGender(rs.getString("gender"));
              e.setSal(rs.getFloat("sal"));
              e.setName(rs.getString("name"));
              al.add(e);
              
            }
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(Emp1DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return al;
     }
      
    
    
    public static void main(String[] args) {
        
        // 1.call save employee method
//        Emp1Bean eb=new Emp1Bean();
//        eb.setSal(33000);
//        eb.setName("karmika");
//        eb.setComm(180);
//        eb.setDeptno(30);
//        eb.setGender("Female");
//        Emp1DAO ed=new Emp1DAO();
//        int x=ed.saveEmployee(eb);
//        if(x>0){
//            System.out.println("Employee Added Success");
//        }
//        else{
//            System.out.println("Employee not Added");
//        }


      //2.call Update employee method
//   Emp1Bean eb = new Emp1Bean();
//   eb.setComm(91);
//   eb.setDeptno(10);
//   eb.setEmpnno(5);
//   eb.setGender("Male");
//   eb.setName("Harsh");
//   eb.setSal(75000);
//   Emp1DAO ed = new Emp1DAO();
//   int x=ed.updateEmployee(eb);
//   if(x>0){
//       System.out.println("Data Update Success");
//   }
//   else{
//   
//       System.out.println("Data update fail");
//   }

//3.call delete employeee method
//Emp1DAO dao=new Emp1DAO();
//int x=dao.deleteEmployee(4);
//if(x>0){
//    System.out.println("Data delete Success");
//}
//else{
//    System.out.println("Data not Deleted");
//}

//4.call findAll method 
//        Emp1DAO dao=new Emp1DAO();
//        ArrayList<Emp1Bean>al=dao.findAll();
//        for(Emp1Bean x:al){
//            System.out.println("\t"+x.getName()+"\t"+x.getSal()+"\t"+x.getGender()+"\t"+x.getDeptno()+"\t"+x.getEmpnno()+"\t"+x.getComm());
//            
//        }
//    }
// 
//}

//5. call findByGender method 

// Emp1DAO dao=new Emp1DAO();
//        ArrayList<Emp1Bean>al=dao.findByGender("female");
//        System.out.println("Data of all female candidate");
//        for(Emp1Bean x:al){
//            System.out.println("\t"+x.getName()+"\t"+x.getSal()+"\t"+x.getGender()+"\t"+x.getDeptno()+"\t"+x.getEmpnno()+"\t"+x.getComm());
//            
//        }

////6. Call  getTotalSalary method
//
//Emp1DAO ed=new Emp1DAO();
//float sal=ed.getTotalSalary();
//        System.out.println("Total Salary of All Employee: "+sal);
        
//7. Call  getAverageSalary method

//Emp1DAO ed=new Emp1DAO();
//float sal=ed.getAverageSalary();
//        System.out.println("Total Average of All Employee: "+sal);
//        

//8. Call  findAllByDeptno method

// Emp1DAO dao=new Emp1DAO();
//        ArrayList<Emp1Bean>al=dao.findAllByDeptno(20);
//        System.out.println("Data of all given deptno");
//        for(Emp1Bean x:al){
//            System.out.println("\t"+x.getName()+"\t"+x.getSal()+"\t"+x.getGender()+"\t"+x.getDeptno()+"\t"+x.getEmpnno()+"\t"+x.getComm());
//
//    }

////9. call getHighestSalariedEmployee method
//
//Emp1DAO dao=new Emp1DAO();
//        ArrayList<Emp1Bean>al=dao.getHighestSalariedEmployee();
//        System.out.println("Data of Highest paid employee");
//        for(Emp1Bean x:al){
//            System.out.println("\t"+x.getName()+"\t"+x.getSal()+"\t"+x.getGender()+"\t"+x.getDeptno()+"\t"+x.getEmpnno()+"\t"+x.getComm());
//
//    }

//10. call getLowestSalariedEmployee method

Emp1DAO dao=new Emp1DAO();
        ArrayList<Emp1Bean>al=dao.getLowestSalariedEmployee();
        System.out.println("Data of Lowestest paid employee");
        for(Emp1Bean x:al){
            System.out.println("\t"+x.getName()+"\t"+x.getSal()+"\t"+x.getGender()+"\t"+x.getDeptno()+"\t"+x.getEmpnno()+"\t"+x.getComm());

    }


}
}

