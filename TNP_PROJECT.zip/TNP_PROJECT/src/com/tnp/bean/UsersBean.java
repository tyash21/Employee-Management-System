/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tnp.bean;

/**
 *
 * @author yasht
 */
public class UsersBean {

    private int uid;
    private String name;
    private String email;
    private String address;
    private String mobile;
    private String userName;
    private String password;

    public UsersBean() {
    }

    public UsersBean(int uid, String name, String email, String address, String mobile, String userName, String password) {
        this.uid = uid;
        this.name = name;
        this.email = email;
        this.address = address;
        this.mobile = mobile;
        this.userName = userName;
        this.password = password;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
    
    

}
