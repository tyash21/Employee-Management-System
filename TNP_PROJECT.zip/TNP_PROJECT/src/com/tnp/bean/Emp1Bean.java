/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tnp.bean;

/**
 *
 * @author yasht
 */
public class Emp1Bean {
    private int empnno;
    private String name;
    private float sal;
    private int deptno;
    private float comm;
    private String gender;

    public Emp1Bean() {
    }

    public Emp1Bean(int empnno, String name, float sal, int deptno, float comm, String gender) {
        this.empnno = empnno;
        this.name = name;
        this.sal = sal;
        this.deptno = deptno;
        this.comm = comm;
        this.gender = gender;
    }

    public int getEmpnno() {
        return empnno;
    }

    public void setEmpnno(int empnno) {
        this.empnno = empnno;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getSal() {
        return sal;
    }

    public void setSal(float sal) {
        this.sal = sal;
    }

    public int getDeptno() {
        return deptno;
    }

    public void setDeptno(int deptno) {
        this.deptno = deptno;
    }

    public float getComm() {
        return comm;
    }

    public void setComm(float comm) {
        this.comm = comm;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void getGender(String male) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
